package com.example.profiledesign

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.net.Uri

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        }

    fun openFacebook() {
        val fBPageID = "https://www.facebook.com/notaweebbtw"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(fBPageID))
        startActivity(intent)
    }

    fun openGithub() {
        val githubPageID = "https://github.com/jlbaq"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(githubPageID))
        startActivity(intent)
    }

    fun openInsta() {
        val instaPageID = "https://www.instagram.com/yojimboiii/"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(instaPageID))
        startActivity(intent)
    }
}